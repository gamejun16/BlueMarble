#ifndef __Maintap__
#define __Maintap__

extern float bgm_sound;

void Scene_Maintap_Init();

bool Scene_Maintap_Render(float timeDelta);

#endif