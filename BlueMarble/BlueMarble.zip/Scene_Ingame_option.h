#ifndef __INGAME_OPTION__
#define __INGAME_OPTION__

void Scene_Ingame_Option_Init();
bool Scene_Ingame_Option_Render(float timeDelta);

extern float fVolume;


#endif