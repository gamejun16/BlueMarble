#ifndef __GAMEOVER__
#define __GAMEOVER__



void Scene_Gameover_Init();

bool Scene_Gameover_Render(float timeDelta);


#endif