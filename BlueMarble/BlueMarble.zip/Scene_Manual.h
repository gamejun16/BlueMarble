#ifndef __MANUAL__
#define __MANUAL__

void Scene_Manual_Init();

bool Scene_Manual_Render(float timeDelta);

#endif