#ifndef __SET_AREA__
#define __SET_AREA__

void Set_Area(struct fields *f);

#endif
