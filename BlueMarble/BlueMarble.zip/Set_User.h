#ifndef __SET_USER__
#define __SET_USER__

void Set_User(struct PLAYER *a, struct PLAYER *b, struct PLAYER *c, struct PLAYER *d);

#endif