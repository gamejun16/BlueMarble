#ifndef __FIXAREA__
#define __FIXAREA__


void Scene_FixArea_Init();

bool Scene_FixArea_Render(float timeDelta);


#endif
