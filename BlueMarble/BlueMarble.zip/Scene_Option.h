#ifndef __OPTION__
#define __OPTION__

void Scene_Option_Init();
bool Scene_Option_Render(float timeDelta);

//extern//
extern float fVolume;
extern int fVolume_int;
extern bool BGM_on;

#endif